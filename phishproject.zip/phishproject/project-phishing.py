# Universal File Email Agent - Handles various file types with user confirmation
# Requirements: pip install langchain-google-genai watchdog yagmail

import os
import json
import time
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import yagmail
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.schema import HumanMessage
import hashlib
import urllib.parse
import json
import os

# Configuration
MONITOR_FOLDER = "data"
GEMINI_API_KEY = ""
SUPPORTED_EXTENSIONS = ['.json', '.txt', '.md']
HASH_MAP_FILE = "email_hash_map.json"

# Link Configuration - Set your secure link here
SECURE_LINK_URL = "https://localhost:8080/secure/"  # Change this to your actual secure link
LINK_DESCRIPTION = "secure portal"  # Description of what the link leads to
ORGANIZATION_NAME = "NovelTechSolutions"  # Your organization name

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)



def create_hashed_url(email: str) -> str:
    # Normalize email
    normalized_email = email.strip().lower()
    
    # SHA256 hash
    email_hash = hashlib.sha256(normalized_email.encode()).hexdigest()
    
    # Join with base URL
    hashed_url = urllib.parse.urljoin(SECURE_LINK_URL, email_hash)

    # Load existing hash map or create new one
    if os.path.exists(HASH_MAP_FILE):
        with open(HASH_MAP_FILE, "r") as f:
            email_map = json.load(f)
    else:
        email_map = {}

    # Add or update mapping
    email_map[normalized_email] = email_hash

    # Save updated mapping back to file
    with open(HASH_MAP_FILE, "w") as f:
        json.dump(email_map, f, indent=4)

    return hashed_url

def initialize_llm() -> ChatGoogleGenerativeAI:
    """Initialize Gemini LLM with API key."""
    if not GEMINI_API_KEY:
        raise ValueError("GEMINI_API_KEY environment variable not set")
    
    return ChatGoogleGenerativeAI(
        model="gemini-2.0-flash",
        google_api_key=GEMINI_API_KEY,
        temperature=0.3
    )

def read_file_content(file_path: str) -> Tuple[Optional[str], str]:
    """Read file content and determine file type."""
    try:
        file_extension = Path(file_path).suffix.lower()
        
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
            
        if file_extension == '.json':
            # Try to parse as JSON to validate
            try:
                json.loads(content)
                return content, 'json'
            except json.JSONDecodeError:
                return content, 'text'  # Treat as text if JSON parsing fails
        elif file_extension in ['.txt', '.md']:
            return content, 'text'
        else:
            return content, 'unknown'
            
    except Exception as e:
        logger.error(f"Error reading file {file_path}: {e}")
        return None, 'error'

def extract_context_from_json(content: str) -> str:
    """Extract context from JSON content (Slack format)."""
    try:
        data = json.loads(content)
        
        if 'messages' in data:
            # Slack conversation format
            channel_info = data.get('channel', {})
            messages = data['messages']
            
            context_parts = [
                f"Source: Slack conversation from channel '{channel_info.get('name', 'Unknown')}'",
                f"Purpose: {channel_info.get('purpose', 'No description')}",
                f"Total messages: {len(messages)}",
                "\nConversation highlights:"
            ]
            
            # Get key messages
            for msg in messages[-15:]:  # Last 15 messages for context
                if msg.get('type') == 'message' and 'user_profile' in msg:
                    user = msg['user_profile'].get('display_name', 'Unknown')
                    text = msg.get('text', '')
                    if text.strip():  # Only include non-empty messages
                        context_parts.append(f"- {user}: {text}")
            
            return "\n".join(context_parts)
        else:
            # Generic JSON - try to extract meaningful info
            return f"JSON Data Summary:\n{str(data)[:1000]}..."
            
    except Exception as e:
        logger.error(f"Error extracting JSON context: {e}")
        return content[:1000] + "..." if len(content) > 1000 else content

def extract_context_from_text(content: str) -> str:
    """Extract context from text content."""
    # For articles or plain text, provide first part as context
    lines = content.split('\n')
    
    # Try to identify if it's an article with title
    title = lines[0] if lines else "Untitled"
    
    context_parts = [
        f"Source: Text document/article",
        f"Title/First line: {title}",
        f"Content length: {len(content)} characters",
        f"Number of lines: {len(lines)}",
        "\nContent preview:"
    ]
    
    # Add first few meaningful lines
    meaningful_lines = [line.strip() for line in lines[:10] if line.strip()]
    for line in meaningful_lines[:5]:
        context_parts.append(f"- {line}")
    
    if len(content) > 500:
        context_parts.append(f"\n[Content continues for {len(content) - 500} more characters...]")
    
    return "\n".join(context_parts)

def extract_all_emails_from_content(content: str, file_type: str) -> List[Dict[str, str]]:
    """Extract all email addresses and associated names from content."""
    import re
    
    emails_found = []
    
    if file_type == 'json':
        try:
            data = json.loads(content)
            if 'messages' in data:
                # Extract from Slack user profiles
                seen_users = set()
                for msg in data['messages']:
                    if 'user_profile' in msg and msg.get('user') not in seen_users:
                        profile = msg['user_profile']
                        name = profile.get('display_name', profile.get('real_name', 'Unknown'))
                        email = profile.get('email', '')
                        if email and '@' in email:
                            emails_found.append({
                                'name': name,
                                'email': email,
                                'title': profile.get('title', ''),
                                'source': 'slack_profile'
                            })
                        seen_users.add(msg.get('user'))
        except:
            pass
    
    # Extract emails from text using regex
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    found_emails = re.findall(email_pattern, content)
    
    for email in found_emails:
        # Try to find associated name near the email
        email_index = content.find(email)
        surrounding_text = content[max(0, email_index-100):email_index+100]
        
        # Simple name extraction patterns
        name_patterns = [
            r'([A-Z][a-z]+ [A-Z][a-z]+)\s*[<(]?' + re.escape(email),
            r'([A-Z][a-z]+ [A-Z]\. [A-Z][a-z]+)\s*[<(]?' + re.escape(email),
            r'Contact:?\s*([A-Z][a-z]+ [A-Z][a-z]+).*?' + re.escape(email),
        ]
        
        name = "Unknown"
        for pattern in name_patterns:
            match = re.search(pattern, surrounding_text, re.IGNORECASE)
            if match:
                name = match.group(1)
                break
        
        emails_found.append({
            'name': name,
            'email': email,
            'title': '',
            'source': 'text_extraction'
        })
    
    return emails_found

def analyze_content_for_email_context(content: str, file_type: str, llm: ChatGoogleGenerativeAI) -> Dict[str, Any]:
    """Analyze content to understand email context and participants."""
    
    # First, extract all available emails from content
    available_emails = extract_all_emails_from_content(content, file_type)
    
    # Extract appropriate context based on file type
    if file_type == 'json':
        context = extract_context_from_json(content)
    else:
        context = extract_context_from_text(content)
    
    # Prepare email directory for LLM
    email_directory = "\n".join([
        f"- {person['name']} ({person['title']}): {person['email']}" 
        for person in available_emails
    ]) if available_emails else "No email addresses found in content"
    
    # Create comprehensive analysis prompt
    prompt = f"""
    Analyze this content to understand the email communication context:
    
    File Type: {file_type}
    
    Available Email Addresses Found:
    {email_directory}
    
    Content Context:
    {context}
    
    Your task is to identify:
    1. Who should send a follow-up email (sender) - MUST pick from available emails above
    2. Who should receive the email (recipient) - MUST pick from available emails above
    3. What the email should be about
    
    IMPORTANT: You MUST only use email addresses that were found in the content above. 
    Do NOT suggest NEEDS_INPUT - work with what's available.
    
    Look for:
    - People who have responsibilities or commitments
    - People waiting for information  
    - Action items or follow-ups needed
    - Professional relationships and hierarchies
    - Who was coordinating tasks or providing information
    - Who was asking for updates or credentials
    
    If multiple people are available, choose the most appropriate based on:
    - Leadership roles or seniority
    - Who has the information to share
    - Who was driving the conversation or tasks
    
    If this is an article/document with limited participants, be creative:
    - Author could email colleagues
    - Team members could share with stakeholders
    - Use professional judgment based on content
    
    Respond in this exact format:
    ANALYSIS_TYPE: [slack_conversation|article|document|other]
    SENDER_NAME: [Name of person who should send email - must be from available emails]
    SENDER_EMAIL: [Email address - must be from available emails above]
    RECIPIENT_NAME: [Name of person who should receive email - must be from available emails]
    RECIPIENT_EMAIL: [Email address - must be from available emails above]
    EMAIL_PURPOSE: [Brief description of why email should be sent]
    CONFIDENCE: [HIGH|MEDIUM|LOW - how confident you are in this analysis]
    REASONING: [Brief explanation of your analysis and why you chose these specific people]
    AVAILABLE_EMAILS_COUNT: {len(available_emails)}
    """
    
    try:
        response = llm.invoke([HumanMessage(content=prompt)])
        response_text = response.content
        
        # Parse response into structured data
        analysis = {}
        for line in response_text.strip().split('\n'):
            if ':' in line:
                key, value = line.split(':', 1)
                analysis[key.strip()] = value.strip()
        
        # Add the available emails for reference
        analysis['AVAILABLE_EMAILS'] = available_emails
        
        return analysis
        
    except Exception as e:
        logger.error(f"Error analyzing content: {e}")
        return {'AVAILABLE_EMAILS': available_emails}

def craft_email_content(content: str, file_type: str, analysis: Dict[str, Any], llm: ChatGoogleGenerativeAI) -> Tuple[str, str]:
    """Craft email subject and body based on analysis with secure link integration."""
    
    context = extract_context_from_json(content) if file_type == 'json' else extract_context_from_text(content)
    
    prompt = f"""
    Craft a professional email based on this analysis and content:
    
    Email Context:
    - From: {analysis.get('SENDER_NAME', 'Unknown')}
    - To: {analysis.get('RECIPIENT_NAME', 'Unknown')}
    - Purpose: {analysis.get('EMAIL_PURPOSE', 'Follow-up')}
    - Type: {analysis.get('ANALYSIS_TYPE', 'unknown')}
    
    Source Content Summary:
    {context[:800]}...
    
    IMPORTANT INSTRUCTIONS:
    1. Do NOT include any sensitive information, secrets, credentials, or detailed content directly in the email
    2. Instead, refer the recipient to access detailed information through a secure link
    3. The secure link is: {create_hashed_url(analysis.get('RECIPIENT_EMAIL', 'Unknown'))}
    4. Describe the link as "{LINK_DESCRIPTION}" 
    5. Organization name: {ORGANIZATION_NAME}
    
    Create a professional email that:
    1. Has an appropriate subject line
    2. Maintains professional tone
    3. Provides brief context about what information is available
    4. Directs the recipient to click the secure link for detailed information
    5. Includes appropriate call-to-action to access the link
    6. Does NOT embed sensitive details directly in the email body
    
    Example structure:
    - Brief greeting and context
    - Summary of what information is available (without details)
    - Clear instruction to access the secure link for full details
    - Professional closing
    
    Respond in this exact format:
    SUBJECT: [Email subject line]
    
    BODY:
    [Email body content with secure link reference]
    """
    
    try:
        response = llm.invoke([HumanMessage(content=prompt)])
        response_text = response.content
        
        # Parse response
        parts = response_text.split('BODY:', 1)
        if len(parts) == 2:
            subject = parts[0].replace('SUBJECT:', '').strip()
            body = parts[1].strip()
            
            # Ensure the secure link is properly included
            if SECURE_LINK_URL not in body:
                body += f"\n\nPlease access the {LINK_DESCRIPTION} for detailed information: {create_hashed_url(analysis.get('RECIPIENT_EMAIL', 'Unknown'))}"
            
            return subject, body
        else:
            # Fallback with secure link
            return "Information Access Required", f"Please access the {LINK_DESCRIPTION} for the requested information: {create_hashed_url(analysis.get('RECIPIENT_EMAIL', 'Unknown'))}"
            
    except Exception as e:
        logger.error(f"Error crafting email: {e}")
        return "Information Access Required", f"Please access the {LINK_DESCRIPTION} for detailed information: {create_hashed_url(analysis.get('RECIPIENT_EMAIL', 'Unknown'))}"

def validate_extracted_emails(analysis: Dict[str, Any]) -> Dict[str, str]:
    """Validate and return extracted email addresses."""
    emails = {
        'sender': analysis.get('SENDER_EMAIL', ''),
        'recipient': analysis.get('RECIPIENT_EMAIL', '')
    }
    
    # Check if we have valid email addresses
    if not emails['sender'] or '@' not in emails['sender']:
        logger.error(f"No valid sender email found. Analysis returned: {emails['sender']}")
        return None
    
    if not emails['recipient'] or '@' not in emails['recipient']:
        logger.error(f"No valid recipient email found. Analysis returned: {emails['recipient']}")
        return None
    
    return emails

def display_email_preview(analysis: Dict[str, Any], emails: Dict[str, str], subject: str, body: str) -> bool:
    """Display email preview and get user confirmation."""
    
    print("\n" + "="*60)
    print("EMAIL PREVIEW")
    print("="*60)
    print(f"From: {analysis.get('SENDER_NAME', 'Unknown')} <{emails.get('sender', 'Unknown')}>")
    print(f"To: {analysis.get('RECIPIENT_NAME', 'Unknown')} <{emails.get('recipient', 'Unknown')}>")
    print(f"Subject: {subject}")
    print(f"Purpose: {analysis.get('EMAIL_PURPOSE', 'Not specified')}")
    print(f"Confidence: {analysis.get('CONFIDENCE', 'Unknown')}")
    print(f"🔗 Secure Link: {create_hashed_url(analysis.get('RECIPIENT_EMAIL', 'Unknown'))}")
    print("-" * 60)
    print("Body:")
    print(body)
    print("="*60)
    
    if analysis.get('REASONING'):
        print(f"AI Reasoning: {analysis.get('REASONING')}")
        print("-" * 60)
    
    while True:
        choice = input("\nDo you want to send this email? (y/n/e to edit): ").lower().strip()
        if choice in ['y', 'yes']:
            return True
        elif choice in ['n', 'no']:
            return False
        elif choice in ['e', 'edit']:
            print("\nEdit options:")
            new_subject = input(f"New subject (press Enter to keep current): ").strip()
            if new_subject:
                subject = new_subject
            
            print("New body (press Enter twice when done):")
            new_body_lines = []
            while True:
                line = input()
                if line == "" and len(new_body_lines) > 0 and new_body_lines[-1] == "":
                    break
                new_body_lines.append(line)
            
            if new_body_lines:
                body = "\n".join(new_body_lines[:-1])  # Remove last empty line
                
                # Ensure secure link is still included after editing
                if {create_hashed_url(analysis.get('RECIPIENT_EMAIL', 'Unknown'))} not in body:
                    body += f"\n\nPlease access the {LINK_DESCRIPTION} for detailed information: {create_hashed_url(analysis.get('RECIPIENT_EMAIL', 'Unknown'))}"
            
            # Update the preview
            return display_email_preview(analysis, emails, subject, body)
        else:
            print("Please enter 'y' for yes, 'n' for no, or 'e' to edit.")

def send_email_demo(from_email: str, to_email: str, subject: str, body: str) -> bool:
    """Demo email sending - replace with actual email service."""
    try:
        print(f"\n[DEMO] Sending email...")
        print(f"From: {from_email}")
        print(f"To: {to_email}")
        print(f"Subject: {subject}")
        print(f"Body length: {len(body)} characters")
        # print(f"🔗 Contains secure link: {'Yes' if {create_hashed_url(analysis.get('RECIPIENT_EMAIL', 'Unknown'))} in body else 'No'}")
        
        # For actual implementation, uncomment and configure:
        # yag = yagmail.SMTP(from_email, password='your_app_password')
        # yag.send(to=to_email, subject=subject, contents=body)
        
        print("[DEMO] Email sent successfully!")
        return True
        
    except Exception as e:
        logger.error(f"Error sending email: {e}")
        return False

def process_file(file_path: str, llm: ChatGoogleGenerativeAI) -> None:
    """Process a file and handle email automation with user confirmation."""
    logger.info(f"Processing file: {file_path}")
    
    # Read file content
    content, file_type = read_file_content(file_path)
    if not content:
        logger.error(f"Failed to read content from {file_path}")
        return
    
    print(f"\n📄 Processing: {os.path.basename(file_path)} (Type: {file_type})")
    # print(f"🔗 Configured secure link: {create_hashed_url(analysis.get('RECIPIENT_EMAIL', 'Unknown'))}")
    
    # Analyze content for email context
    analysis = analyze_content_for_email_context(content, file_type, llm)
    if not analysis:
        logger.error("Failed to analyze content")
        return
    
    # Show available emails found
    available_emails = analysis.get('AVAILABLE_EMAILS', [])
    print(f"📧 Found {len(available_emails)} email addresses in content:")
    for email_info in available_emails:
        print(f"   • {email_info['name']} - {email_info['email']}")
    
    print(f"🔍 Analysis complete. Confidence: {analysis.get('CONFIDENCE', 'Unknown')}")
    
    # Validate that we have the required email addresses
    emails = validate_extracted_emails(analysis)
    if not emails:
        print("❌ Could not find valid sender and recipient email addresses in the content.")
        print("💡 Make sure the file contains email addresses for both sender and recipient.")
        if available_emails:
            print("Available emails found:")
            for email_info in available_emails:
                print(f"   • {email_info['name']}: {email_info['email']}")
        return
    
    print(f"✅ Identified email flow:")
    print(f"   From: {analysis.get('SENDER_NAME')} <{emails['sender']}>")
    print(f"   To: {analysis.get('RECIPIENT_NAME')} <{emails['recipient']}>")
    
    # Craft email content
    subject, body = craft_email_content(content, file_type, analysis, llm)
    
    # Show preview and get confirmation
    if display_email_preview(analysis, emails, subject, body):
        # Send email
        success = send_email_demo(emails['sender'], emails['recipient'], subject, body)
        
        if success:
            print("✅ Email sent successfully!")
            # Move processed file
            processed_path = file_path.replace(Path(file_path).suffix, '_processed' + Path(file_path).suffix)
            os.rename(file_path, processed_path)
            print(f"📁 File moved to: {processed_path}")
        else:
            print("❌ Failed to send email")
    else:
        print("📧 Email sending cancelled by user")

class FileHandler(FileSystemEventHandler):
    """Handle new files in the monitored folder."""
    
    def __init__(self, llm: ChatGoogleGenerativeAI):
        self.llm = llm
        super().__init__()
    
    def on_created(self, event):
        if not event.is_directory:
            file_extension = Path(event.src_path).suffix.lower()
            if file_extension in SUPPORTED_EXTENSIONS:
                logger.info(f"New file detected: {event.src_path}")
                # Wait a moment to ensure file is fully written
                time.sleep(2)
                process_file(event.src_path, self.llm)

def setup_monitoring(llm: ChatGoogleGenerativeAI) -> Observer:
    """Set up file system monitoring."""
    if not os.path.exists(MONITOR_FOLDER):
        os.makedirs(MONITOR_FOLDER)
        logger.info(f"Created {MONITOR_FOLDER} directory")
    
    event_handler = FileHandler(llm)
    observer = Observer()
    observer.schedule(event_handler, MONITOR_FOLDER, recursive=False)
    
    return observer

def process_existing_files(llm: ChatGoogleGenerativeAI) -> None:
    """Process any existing unprocessed files."""
    folder_path = Path(MONITOR_FOLDER)
    
    for ext in SUPPORTED_EXTENSIONS:
        files = list(folder_path.glob(f"*{ext}"))
        unprocessed_files = [f for f in files if not str(f).endswith(f'_processed{ext}')]
        
        if unprocessed_files:
            print(f"\n📂 Found {len(unprocessed_files)} unprocessed {ext} files")
            for file_path in unprocessed_files:
                process_file(str(file_path), llm)

def main():
    """Main function to run the universal file email agent."""
    print("🤖 Starting Universal File Email Agent...")
    print(f"📁 Monitoring folder: {MONITOR_FOLDER}")
    print(f"📄 Supported file types: {', '.join(SUPPORTED_EXTENSIONS)}")
    print(f"🔗 Secure link configured: {SECURE_LINK_URL}")
    print(f"🏢 Organization: {ORGANIZATION_NAME}")
    
    try:
        # Initialize LLM
        llm = initialize_llm()
        logger.info("LLM initialized successfully")
        
        # Process existing files
        process_existing_files(llm)
        
        # Set up monitoring
        observer = setup_monitoring(llm)
        observer.start()
        print(f"👀 Monitoring {MONITOR_FOLDER} folder for new files...")
        print("Press Ctrl+C to stop")
        
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            observer.stop()
            print("\n🛑 Stopping agent...")
        
        observer.join()
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")

if __name__ == "__main__":
    main()