// function loadClicks() {
//     $.get("/clicks", function(data) {
//         let tbody = $("#clickTable tbody");
//         tbody.empty();
//         data.forEach(function(entry) {
//             let row = `<tr><td>${entry.timestamp}</td><td>${entry.email}</td></tr>`;
//             tbody.append(row);
//         });
//     });
// }

// setInterval(loadClicks, 1000);  // Update every second


$(document).ready(function () {
  let knownClicks = new Set();

  function fetchClicks() {
    $.getJSON("/clicks", function (data) {
      const tbody = $("#clickTable tbody");

      // Remove "no data" row if present
      tbody.find("tr.no-data").remove();

      // Reverse so newest first
      const reversed = data.slice().reverse();

      let newRowsAdded = false;

      reversed.forEach((entry) => {
        const key = entry.timestamp + "|" + entry.email;

        // Only add if not already known (efficient update)
        if (!knownClicks.has(key)) {
          knownClicks.add(key);
          const newRow = $(`
            <tr class="new-row">
              <td>${entry.timestamp}</td>
              <td>${entry.email}</td>
            </tr>
          `);

          // Insert at top with fade-in animation
          tbody.prepend(newRow);

          // Remove the animation class after animation completes to avoid re-triggers
          newRow.on("animationend webkitAnimationEnd oAnimationEnd MSAnimationEnd", function () {
            $(this).removeClass("new-row");
          });

          newRowsAdded = true;
        }
      });

      // If no data at all
      if (knownClicks.size === 0 && !tbody.find("tr.no-data").length) {
        tbody.html('<tr class="no-data"><td colspan="2">No clicks recorded yet.</td></tr>');
      }
    });
  }

  // Fetch immediately and then every 1 sec
  fetchClicks();
  setInterval(fetchClicks, 1000);
});
