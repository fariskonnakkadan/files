from flask import Flask, request, jsonify, render_template
import json
import os
from datetime import datetime

app = Flask(__name__)

EMAIL_HASH_FILE = "email_hash_map.json"
CLICK_LOG_FILE = "log.json"

# Ensure log file exists
if not os.path.exists(CLICK_LOG_FILE):
    with open(CLICK_LOG_FILE, "w") as f:
        json.dump([], f)

# Load hash-to-email mapping
with open(EMAIL_HASH_FILE) as f:
    email_hash_map = json.load(f)

# Reverse map hash -> email
hash_to_email = {v: k for k, v in email_hash_map.items()}

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/clicks")
def get_clicks():
    with open(CLICK_LOG_FILE) as f:
        logs = json.load(f)
    return jsonify(logs[::-1])  # latest first

@app.route("/secure/<hash_value>")
def secure_link(hash_value):
    with open(EMAIL_HASH_FILE) as f:
        email_hash_map = json.load(f)
    hash_to_email = {v: k for k, v in email_hash_map.items()}
    
    email = hash_to_email.get(hash_value)
    if email:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = {"timestamp": now, "email": email}
        
        with open(CLICK_LOG_FILE) as f:
            logs = json.load(f)
        logs.append(entry)
        with open(CLICK_LOG_FILE, "w") as f:
            json.dump(logs, f, indent=2)
        
        return render_template("done.html")
    return "Invalid or unknown hash.", 404

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, debug=True)
