from flask import Flask, jsonify, render_template_string
import json
from pathlib import Path

app = Flask(__name__)

@app.route('/')
def index():
    with open("email_dashboard_app.html") as f:
        return render_template_string(f.read())

@app.route('/emails')
def get_emails():
    try:
        with open("email.json", "r") as f:
            emails = json.load(f)
        return jsonify(emails)
    except Exception as e:
        return jsonify([]), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8081, debug=True)
